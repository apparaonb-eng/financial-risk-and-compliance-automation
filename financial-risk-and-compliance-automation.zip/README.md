# Financial Risk and Compliance Automation

A simple rule-based Python engine that screens financial transactions for AML / compliance red flags, scores customer risk, and produces alert reports.

## Rules
| Rule | Severity | Triggers when |
|------|----------|---------------|
| `LARGE_TRANSACTION` | MEDIUM | A single transaction >= reporting threshold (default 10,000) |
| `STRUCTURING` | HIGH | 3+ transactions between 8,000 and 10,000 within 48 hours |
| `HIGH_VELOCITY` | MEDIUM | More than 8 transactions within 24 hours |
| `HIGH_RISK_COUNTRY` | HIGH | Counterparty is in a high-risk jurisdiction |
| `SANCTIONS_HIT` | HIGH | Counterparty name matches the sanctions watchlist |

Customer risk score = sum of alert weights (LOW 5, MEDIUM 15, HIGH 30), capped at 100.
Bands: LOW (<25), MEDIUM (25-59), HIGH (60+).

## Files
| File | Purpose |
|------|---------|
| `compliance_engine.py` | Config, rules, engine, scoring, CSV/JSON export |
| `main.py` | Runner: generates sample data or screens your CSV |
| `test_compliance.py` | Unit tests |

## Run
```bash
python main.py                    # sample data -> alerts_report.csv, customer_risk.json
python main.py transactions.csv   # your own data
python -m unittest -v             # tests
```

Input CSV columns: `txn_id,customer_id,timestamp,amount,currency,counterparty,counterparty_country`
(timestamp ISO format, e.g. `2026-11-20T14:30:00`).

## Customising
Edit `Config` in `compliance_engine.py` (thresholds, high-risk countries, watchlist), or add a new rule function with the signature `rule(txns_of_one_customer, config) -> list[Alert]` and append it to `DEFAULT_RULES`.

## Notes
This is a learning/demo project. The watchlist and country list are placeholders, not real regulatory data.
